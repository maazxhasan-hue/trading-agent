from agent.config import Settings
from agent.polymarket import Polymarket
s=Settings(); s.validate()
p=Polymarket(s.gamma_url,s.clob_url)
m={"resolutionSource":"https://example.com","endDate":"2027-01-01T04:59:00Z","liquidity":5001}
assert p.resolution_source(m)
assert p.end_time(m)
assert p.liquidity(m)>5000
print("SMOKE TEST OK")
