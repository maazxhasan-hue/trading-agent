# Polymarket Standalone Agent

Self-contained Python/Termux project. No GitHub is required.

Safety defaults:
- PAPER mode
- 8 percentage-point minimum edge
- model-confidence gate 99% (not a 99% win guarantee)
- half-Kelly sizing
- 6% maximum position
- 5 maximum open positions
- 3% maximum slippage
- 40% drawdown kill switch
- phone heartbeat pause/resume
- persistent SQLite state

Run:
```bash
pkg install python
cd ~/polymarket-standalone-agent
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
python run.py
```

The agent will only trade a market when a current research packet exists in
`data/research_inbox/<market_id>.json`. This prevents it from inventing a
99% confidence score. See `data/research_inbox/example.json`.
