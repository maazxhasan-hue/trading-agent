import compileall,sys
ok=compileall.compile_dir(".",quiet=1)
print("COMPILEALL:", "PASS" if ok else "FAIL")
from agent.config import Settings
from agent.polymarket import Polymarket
from agent.orchestrator import TradingOrchestrator
s=Settings(); s.validate()
print("CONFIG: PASS")
print("ORCHESTRATOR: PASS")
print("PAPER_DEFAULT:", s.mode=="PAPER")
sys.exit(0 if ok else 1)
