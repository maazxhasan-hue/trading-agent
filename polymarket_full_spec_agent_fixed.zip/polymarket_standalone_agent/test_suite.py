import os, tempfile, time, json
from pathlib import Path

os.environ['MODE']='PAPER'
os.environ['DB_PATH']=str(Path(tempfile.gettempdir())/'poly_agent_test.db')
try: Path(os.environ['DB_PATH']).unlink()
except FileNotFoundError: pass

from agent.config import Settings
from agent.polymarket import Polymarket
from agent.research import ResearchInbox
from agent.risk import Risk, half_kelly
from agent.db import DB
from agent.orchestrator import TradingOrchestrator

s=Settings(); s.validate(); assert s.mode=='PAPER'
assert s.min_edge>=.08 and s.min_confidence>=.99 and s.max_position_pct<=.06

m={'resolutionSource':'https://example.com/resolve','endDate':'2099-01-01T00:00:00Z','liquidity':6000,
   'clobTokenIds':[{'token_id':'no','outcome':'No'},{'token_id':'yes','outcome':'Yes'}]}
p=Polymarket(s.gamma_url,s.clob_url)
assert p.resolution_source(m).startswith('https://')
assert p.end_time(m)>time.time()
assert p.liquidity(m)==6000
assert p.token_id(m)=='yes'
assert half_kelly(.7,.5,100)>0
assert Risk(s).approve(100,100,0,.5,.6,.99,0)[0]
assert not Risk(s).approve(100,100,0,.5,.57,.99,0)[0]

root=Path(tempfile.mkdtemp())/'research'
ri=ResearchInbox(root)
market_id='m1'; packet={'fair_probability':.7,'confidence':.995,'evidence':[{'claim':'a','domain':'a.com'},{'claim':'b','domain':'b.com','counterclaim':'c'}], 'resolution_verified':True,'conflict':False,'expires_at':time.time()+1000}
root.mkdir(parents=True,exist_ok=True); (root/(market_id+'.json')).write_text(json.dumps(packet))
loaded=ri.load(market_id); assert loaded and loaded['fair']==.7

# Deterministic specialist/orchestrator checks.
db=DB(str(Path(tempfile.gettempdir())/'poly_agent_orch.db'))
o=TradingOrchestrator(db)
d=o.evaluate(m,packet,m['resolutionSource'],10,.5)
assert d['trade'] and d['edge']>=.08 and d['confidence']>=.99

# Repeat deterministic suite 50 times as requested.
for i in range(50):
    assert Settings().validate() is None
    assert p.token_id(m)=='yes'
    assert p.liquidity(m)==6000
    assert ri.load(market_id)['fair']==.7
    assert o.evaluate(m,packet,m['resolutionSource'],10,.5)['trade']
print('50/50 TEST ROUNDS PASS')
