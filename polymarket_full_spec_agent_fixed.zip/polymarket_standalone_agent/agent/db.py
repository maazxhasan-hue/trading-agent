import sqlite3, json, time
from pathlib import Path

class DB:
    def __init__(self,path):
        Path(path).parent.mkdir(parents=True,exist_ok=True)
        self.c=sqlite3.connect(path,check_same_thread=False)
        self.c.row_factory=sqlite3.Row
        self.c.execute("PRAGMA journal_mode=WAL")
        self.c.execute("CREATE TABLE IF NOT EXISTS state(key TEXT PRIMARY KEY,value TEXT)")
        self.c.execute("CREATE TABLE IF NOT EXISTS scans(id INTEGER PRIMARY KEY,ts REAL,fetched INT,liquidity INT,resolution INT,time INT,token INT,book INT,research INT,signals INT,trades INT,note TEXT)")
        self.c.execute("CREATE TABLE IF NOT EXISTS positions(id INTEGER PRIMARY KEY,market_id TEXT,question TEXT,size REAL,entry_price REAL,fair REAL,category TEXT,opened REAL,status TEXT DEFAULT 'OPEN')")
        self.c.execute("CREATE TABLE IF NOT EXISTS events(id INTEGER PRIMARY KEY,ts REAL,kind TEXT,payload TEXT)")
        self.c.commit()

    def get(self,k,d=None):
        r=self.c.execute("SELECT value FROM state WHERE key=?",(k,)).fetchone()
        return d if r is None else json.loads(r["value"])

    def set(self,k,v):
        self.c.execute("INSERT OR REPLACE INTO state VALUES(?,?)",(k,json.dumps(v)))
        self.c.commit()

    def event(self,k,p):
        self.c.execute("INSERT INTO events(ts,kind,payload) VALUES(?,?,?)",(time.time(),k,json.dumps(p)))
        self.c.commit()

    def scan(self,x):
        self.c.execute("INSERT INTO scans(ts,fetched,liquidity,resolution,time,token,book,research,signals,trades,note) VALUES(?,?,?,?,?,?,?,?,?,?,?)",
                       (time.time(),x["fetched"],x["liquidity"],x["resolution"],x["time"],x["token"],x["book"],x["research"],x["signals"],x["trades"],x.get("note","")))
        self.c.commit()

    def open_positions(self):
        return [dict(r) for r in self.c.execute("SELECT * FROM positions WHERE status='OPEN'")]

    def positions(self):
        return [dict(r) for r in self.c.execute("SELECT * FROM positions ORDER BY id DESC")]

    def add(self,p):
        self.c.execute("INSERT INTO positions(market_id,question,size,entry_price,fair,category,opened) VALUES(?,?,?,?,?,?,?)",
                       (p["market_id"],p["question"],p["size"],p["entry_price"],p["fair"],p["category"],time.time()))
        self.c.commit()
