import time,threading
from .config import Settings
from .db import DB
from .polymarket import Polymarket
from .research import ResearchInbox
from .risk import Risk,half_kelly
from .executor import PaperExecutor
from .orchestrator import TradingOrchestrator

class Agent:
    def __init__(self):
        self.s=Settings(); self.s.validate()
        self.db=DB(self.s.db_path)
        self.api=Polymarket(self.s.gamma_url,self.s.clob_url)
        self.research=ResearchInbox()
        self.risk=Risk(self.s); self.executor=PaperExecutor()
        self.orchestrator=TradingOrchestrator(self.db)
        self.running=False; self.killed=False; self.last_heartbeat=0; self.last_scan=None
        self.bankroll=float(self.db.get("bankroll",100)); self.peak=float(self.db.get("peak",self.bankroll))

    def heartbeat(self):
        if self.killed: return {"accepted":False,"reason":"KILLED"}
        self.last_heartbeat=time.time()
        return {"accepted":True,"running":self.running,"phone_online":True,"last_phone_heartbeat":self.last_heartbeat}

    def online(self): return time.time()-self.last_heartbeat<=self.s.phone_timeout

    def status(self):
        dd=0 if self.peak<=0 else max(0,(self.peak-self.bankroll)/self.peak)
        return {"running":self.running,"killed":self.killed,"phone_online":self.online(),"mode":self.s.mode,
                "executor":"paper","bankroll":self.bankroll,"peak":self.peak,"drawdown":dd,
                "open_positions":len(self.db.open_positions()),"last_scan":self.last_scan}

    def start(self):
        if self.killed: return False
        self.running=True; return True

    def stop(self): self.running=False

    def kill(self): self.running=False; self.killed=True; self.db.set("killed",True)

    def scan_once(self):
        if self.killed: return {"skipped":True,"reason":"KILLED"}
        if not self.online(): return {"skipped":True,"reason":"PHONE_HEARTBEAT_REQUIRED"}
        ms=self.api.markets(self.s.max_markets)
        c={"fetched":len(ms),"liquidity":0,"resolution":0,"time":0,"token":0,"book":0,"research":0,"signals":0,"trades":0}
        for m in ms:
            try:
                if self.api.liquidity(m)<self.s.min_liquidity_usd: continue
                c["liquidity"]+=1
                if not self.api.resolution_source(m): continue
                c["resolution"]+=1
                hrs=self.api.hours_to_resolution(m)
                if hrs is None or hrs<self.s.min_hours: continue
                c["time"]+=1
                token=self.api.token_id(m)
                if not token: continue
                c["token"]+=1
                bid,ask=self.api.best_prices(self.api.book(token))
                if ask is None: continue
                c["book"]+=1
                mid=str(m.get("id") or m.get("conditionId") or "")
                r=self.research.load(mid)
                if not r: continue
                c["research"]+=1
                # ResearchInbox returns the minimum validated fields; enrich with
                # evidence by re-reading the packet for the specialist debate.
                import json
                from pathlib import Path
                rp=Path("data/research_inbox")/(mid+".json")
                packet=json.loads(rp.read_text()) if rp.exists() else {}
                packet["fair_probability"]=r["fair"]; packet["confidence"]=r["confidence"]
                decision=self.orchestrator.evaluate(m,packet,self.api.resolution_source(m),self.api.hours_to_resolution(m),ask)
                edge=decision["edge"]
                if not decision["trade"]: continue
                c["signals"]+=1
                if len(self.db.open_positions())>=self.s.max_open_positions: break
                size=min(half_kelly(r["fair"],ask,self.bankroll),self.bankroll*self.s.max_position_pct)
                ok,_=self.risk.approve(self.bankroll,self.peak,len(self.db.open_positions()),ask,r["fair"],r["confidence"],0)
                if not ok or size<=0: continue
                if self.executor.buy(token,size,ask)["filled"]:
                    self.db.add({"market_id":str(m.get("id")),"question":m.get("question",""),
                                 "size":size,"entry_price":ask,"fair":r["fair"],"category":"research-backed"})
                    c["trades"]+=1
            except Exception as e:
                self.db.event("market_error",{"error":repr(e)})
        self.last_scan=time.time(); self.db.scan(c); return c

    def monitor(self):
        return {"open_positions":len(self.db.open_positions()),"checked":time.time()} if self.online() else {"skipped":True}

    def loop(self):
        self.running=True; ns=0; nm=0
        while self.running and not self.killed:
            if not self.online(): time.sleep(2); continue
            now=time.time()
            if now>=ns:
                try: self.scan_once()
                except Exception as e: self.db.event("scan_error",{"error":repr(e)})
                ns=now+self.s.scan_seconds
            if now>=nm: self.monitor(); nm=now+self.s.monitor_seconds
            time.sleep(1)
