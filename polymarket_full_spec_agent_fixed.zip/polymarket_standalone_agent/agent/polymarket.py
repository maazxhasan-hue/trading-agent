import httpx,time
from datetime import datetime,timezone

class Polymarket:
    def __init__(self,gamma,clob):
        self.c=httpx.Client(timeout=20,follow_redirects=True)
        self.gamma=gamma.rstrip("/")
        self.clob=clob.rstrip("/")

    def markets(self,limit=500):
        r=self.c.get(self.gamma+"/markets",params={"active":"true","closed":"false","limit":min(limit,1000)})
        r.raise_for_status()
        x=r.json()
        if isinstance(x,dict): x=x.get("data") or x.get("markets") or x.get("items") or []
        return x[:limit]

    @staticmethod
    def resolution_source(m):
        for k in ("resolutionSource","resolution_source","resolutionSourceUrl","resolution_source_url"):
            v=m.get(k)
            if isinstance(v,str) and v.strip(): return v.strip()
        return None

    @staticmethod
    def liquidity(m):
        for k in ("liquidity","liquidityNum","volumeNum","volume"):
            try:
                v=float(m.get(k) or 0)
                if v>=0: return v
            except: pass
        return 0.0

    @staticmethod
    def end_time(m):
        for k in ("endDate","endDateIso","end_date"):
            v=m.get(k)
            if not v: continue
            try:
                dt=datetime.fromisoformat(str(v).replace("Z","+00:00"))
                if dt.tzinfo is None: dt=dt.replace(tzinfo=timezone.utc)
                return dt.timestamp()
            except: pass
        return None

    def hours_to_resolution(self,m):
        t=self.end_time(m)
        return None if t is None else (t-time.time())/3600

    @staticmethod
    def token_id(m):
        for k in ("clobTokenIds","clob_token_ids","tokens"):
            v=m.get(k)
            if isinstance(v,list) and v:
                if isinstance(v[0],dict):
                    # Prefer the YES outcome when outcome metadata is available.
                    for q in v:
                        outcome=str(q.get("outcome","")).strip().lower()
                        if outcome in {"yes","true"} and q.get("token_id"):
                            return str(q["token_id"])
                    for q in v:
                        if q.get("token_id"): return str(q["token_id"])
                return str(v[0])
            if isinstance(v,str) and v: return v
        for k in ("yesTokenId","yes_token_id","tokenId"):
            if m.get(k): return str(m[k])
        return None

    def book(self,token):
        r=self.c.get(self.clob+"/book",params={"token_id":token})
        if r.status_code!=200: return None
        return r.json()

    @staticmethod
    def best_prices(book):
        if not book: return None,None
        def p(x):
            try: return float(x.get("price",0)) if isinstance(x,dict) else float(x[0])
            except: return 0
        bids=book.get("bids") or []
        asks=book.get("asks") or []
        bid=max([p(x) for x in bids],default=0)
        asks2=[p(x) for x in asks if p(x)>0]
        ask=min(asks2,default=0)
        return (bid or None),(ask or None)
