class PaperExecutor:
    def buy(self,token,size,price):
        return {"filled":True,"order_id":"PAPER","token_id":token,"size":size,"price":price}
