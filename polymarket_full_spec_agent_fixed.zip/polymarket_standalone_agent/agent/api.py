import json,threading
from http.server import BaseHTTPRequestHandler,HTTPServer
from urllib.parse import urlparse
from .core import Agent

agent=Agent()

def auth(h):
    if h.headers.get("Authorization","")!="Bearer "+agent.s.control_token:
        raise PermissionError

class Handler(BaseHTTPRequestHandler):
    def sendj(self,code,x):
        b=json.dumps(x,default=str).encode()
        self.send_response(code); self.send_header("Content-Type","application/json")
        self.send_header("Content-Length",str(len(b))); self.end_headers(); self.wfile.write(b)

    def do_GET(self):
        try:
            p=urlparse(self.path).path
            if p=="/health": return self.sendj(200,{"ok":True,"service":"polymarket-standalone-agent","mode":agent.s.mode})
            auth(self)
            if p=="/status": return self.sendj(200,agent.status())
            if p=="/positions": return self.sendj(200,{"positions":agent.db.positions()})
            return self.sendj(404,{"detail":"not found"})
        except PermissionError: self.sendj(401,{"detail":"unauthorized"})
        except Exception as e: self.sendj(500,{"detail":repr(e)})

    def do_POST(self):
        try:
            auth(self); p=urlparse(self.path).path
            if p=="/heartbeat": return self.sendj(200,agent.heartbeat())
            if p=="/start":
                agent.start()
                if not getattr(self.server,"started",False):
                    self.server.started=True; threading.Thread(target=agent.loop,daemon=True).start()
                return self.sendj(200,{"started":True})
            if p=="/stop": agent.stop(); return self.sendj(200,{"stopped":True})
            if p=="/kill": agent.kill(); return self.sendj(200,{"killed":True})
            if p=="/scan": return self.sendj(200,agent.scan_once())
            return self.sendj(404,{"detail":"not found"})
        except PermissionError: self.sendj(401,{"detail":"unauthorized"})
        except Exception as e: self.sendj(500,{"detail":repr(e)})

    def log_message(self,*a): pass

def serve():
    s=HTTPServer((agent.s.host,agent.s.port),Handler)
    print("Agent listening on http://%s:%s"%(agent.s.host,agent.s.port))
    s.serve_forever()
