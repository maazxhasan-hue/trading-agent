def half_kelly(p,price,bankroll):
    if bankroll<=0 or not 0<price<1: return 0
    b=(1-price)/price
    k=((b*p-(1-p))/b) if b else 0
    return max(0,k/2)*bankroll

class Risk:
    def __init__(self,s): self.s=s
    def approve(self,bankroll,peak,opens,price,fair,confidence,slippage):
        dd=0 if peak<=0 else max(0,(peak-bankroll)/peak)
        if dd>=self.s.max_drawdown: return False,"DRAWDOWN_STOP"
        if opens>=self.s.max_open_positions: return False,"MAX_OPEN_POSITIONS"
        if confidence<self.s.min_confidence: return False,"CONFIDENCE"
        if fair-price<self.s.min_edge: return False,"EDGE"
        if slippage>self.s.max_slippage: return False,"SLIPPAGE"
        return True,"OK"
