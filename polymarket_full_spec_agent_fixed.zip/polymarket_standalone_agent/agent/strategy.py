
class AdaptiveStrategyManager:
    def __init__(self):
        self.trades=0
        self.wins=0
        self.losses=0
        self.pnl=0.0

    def record(self, pnl: float):
        self.trades += 1
        self.pnl += pnl
        if pnl > 0: self.wins += 1
        elif pnl < 0: self.losses += 1

    def state(self):
        wr=self.wins/self.trades if self.trades else None
        review=(self.trades>=20 and wr is not None and wr<0.45)
        return {"trades":self.trades,"wins":self.wins,"losses":self.losses,
                "win_rate":wr,"pnl":self.pnl,"review_required":review}
