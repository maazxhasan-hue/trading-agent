
from .specialists import ResearchDebate
from .loss_learning import LossInvestigator, CommunityMemory
from .strategy import AdaptiveStrategyManager

class TradingOrchestrator:
    """Coordinates specialist research without fabricating external intelligence."""
    def __init__(self, db):
        self.debate=ResearchDebate()
        self.loss=LossInvestigator()
        self.community=CommunityMemory(db)
        self.strategy=AdaptiveStrategyManager()

    def evaluate(self, market, research, resolution_source, hours, ask):
        return self.debate.decide(market,research,resolution_source,hours,ask)

    def record_loss(self, market_id, pnl, reason="unknown"):
        lesson=self.loss.investigate(market_id,pnl,reason)
        self.community.record(lesson)
        self.strategy.record(pnl)
        return lesson
