
from dataclasses import dataclass, asdict
import time
import json

@dataclass
class LossLesson:
    market_id: str
    pnl: float
    cause: str
    specialist: str
    created_at: float

class LossInvestigator:
    def investigate(self, market_id: str, pnl: float, reason: str = "unknown") -> LossLesson:
        if pnl >= 0:
            cause="not_a_loss"
            specialist="none"
        elif "resolution" in reason.lower():
            cause="resolution_timing"
            specialist="timing_specialist"
        elif "evidence" in reason.lower():
            cause="evidence_quality"
            specialist="evidence_analyst"
        else:
            cause="model_or_execution_error"
            specialist="critic"
        return LossLesson(market_id,pnl,cause,specialist,time.time())

class CommunityMemory:
    def __init__(self, db):
        self.db=db
    def record(self, lesson: LossLesson):
        self.db.event("loss_lesson",asdict(lesson))
    def recent(self, limit=20):
        rows=self.db.c.execute(
            "SELECT payload FROM events WHERE kind='loss_lesson' ORDER BY id DESC LIMIT ?",
            (limit,)).fetchall()
        return [json.loads(r["payload"]) for r in rows]
