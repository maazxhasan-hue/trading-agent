import os
from dataclasses import dataclass

def f(name, default):
    try: return float(os.getenv(name, default))
    except: return float(default)

def i(name, default):
    try: return int(os.getenv(name, default))
    except: return int(default)

@dataclass
class Settings:
    mode: str = os.getenv("MODE","PAPER").upper()
    host: str = os.getenv("HOST","127.0.0.1")
    port: int = i("PORT",8080)
    control_token: str = os.getenv("CONTROL_TOKEN","change-this-token")
    gamma_url: str = os.getenv("GAMMA_URL","https://gamma-api.polymarket.com")
    clob_url: str = os.getenv("CLOB_URL","https://clob.polymarket.com")
    max_markets: int = i("MAX_MARKETS_PER_SCAN",500)
    scan_seconds: int = i("SCAN_SECONDS",300)
    monitor_seconds: int = i("MONITOR_SECONDS",60)
    min_liquidity_usd: float = f("MIN_LIQUIDITY_USD",5000)
    min_hours: float = f("MIN_HOURS_TO_RESOLUTION",2)
    min_edge: float = f("MIN_EDGE",0.08)
    min_confidence: float = f("MIN_CONFIDENCE",0.99)
    max_position_pct: float = f("MAX_POSITION_PCT",0.06)
    max_open_positions: int = i("MAX_OPEN_POSITIONS",5)
    max_slippage: float = f("MAX_SLIPPAGE",0.03)
    max_drawdown: float = f("MAX_DRAWDOWN",0.40)
    live_enabled: bool = os.getenv("LIVE_TRADING_ENABLED","false").lower()=="true"
    live_confirmation: str = os.getenv("LIVE_CONFIRMATION","")
    db_path: str = os.getenv("DB_PATH","data/agent.db")
    phone_timeout: int = i("PHONE_TIMEOUT_SECONDS",120)

    def validate(self):
        if not 0 < self.max_position_pct <= .06: raise ValueError("position cap")
        if self.max_open_positions > 5: raise ValueError("position count cap")
        if self.max_slippage > .03: raise ValueError("slippage cap")
        if self.max_drawdown > .40: raise ValueError("drawdown cap")
        if self.min_edge < .08: raise ValueError("edge floor")
        if self.mode=="LIVE" and (not self.live_enabled or self.live_confirmation!="I_UNDERSTAND_LIVE_TRADING"):
            raise ValueError("LIVE requires explicit confirmation")
