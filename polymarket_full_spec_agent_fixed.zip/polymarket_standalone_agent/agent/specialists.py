
from dataclasses import dataclass
from typing import Any

@dataclass
class Finding:
    specialist: str
    verdict: str
    confidence: float
    claims: list[str]

class ResolutionVerifier:
    name = "resolution_verifier"
    def review(self, market: dict[str, Any], resolution_source: str | None) -> Finding:
        ok = bool(resolution_source)
        return Finding(self.name, "PASS" if ok else "FAIL", 1.0 if ok else 0.0,
                       ["Resolution source present" if ok else "Missing resolution source"])

class BullResearcher:
    name = "bull_researcher"
    def review(self, evidence: list[dict]) -> Finding:
        claims=[str(x.get("claim","")) for x in evidence if isinstance(x,dict)]
        return Finding(self.name, "SUPPORT" if claims else "NO_DATA",
                       min(1.0, 0.5+0.1*len(claims)) if claims else 0.0, claims)

class BearResearcher:
    name = "bear_researcher"
    def review(self, evidence: list[dict]) -> Finding:
        claims=[str(x.get("counterclaim","")) for x in evidence if isinstance(x,dict) and x.get("counterclaim")]
        return Finding(self.name, "COUNTER" if claims else "NO_DATA",
                       min(1.0, 0.5+0.1*len(claims)) if claims else 0.0, claims)

class Critic:
    name = "critic"
    def review(self, research: dict | None) -> Finding:
        if not research:
            return Finding(self.name,"FAIL",0.0,["No research packet"])
        evidence=research.get("evidence",[])
        conflicts=bool(research.get("conflict"))
        claims=[str(x.get("claim","")) for x in evidence if isinstance(x,dict)]
        ok=len(evidence)>=2 and not conflicts
        return Finding(self.name,"PASS" if ok else "FAIL",
                       float(research.get("confidence",0)) if ok else 0.0,
                       claims if ok else ["Insufficient or conflicting evidence"])

class TimingSpecialist:
    name="timing_specialist"
    def review(self,hours: float|None) -> Finding:
        ok=hours is not None and hours>=2
        return Finding(self.name,"PASS" if ok else "FAIL",1.0 if ok else 0.0,
                       [f"{hours:.2f} hours to resolution" if hours is not None else "Unknown resolution time"])

class Strategist:
    name="strategist"
    def rank(self, edge: float, confidence: float) -> float:
        return max(0.0, edge) * max(0.0, min(1.0, confidence))

class ResearchDebate:
    def __init__(self):
        self.resolution=ResolutionVerifier()
        self.bull=BullResearcher()
        self.bear=BearResearcher()
        self.critic=Critic()
        self.timing=TimingSpecialist()
        self.strategist=Strategist()

    def decide(self, market, research, source, hours, ask):
        findings=[
            self.resolution.review(market,source),
            self.bull.review(research.get("evidence",[]) if research else []),
            self.bear.review(research.get("evidence",[]) if research else []),
            self.critic.review(research),
            self.timing.review(hours),
        ]
        fair=float(research["fair_probability"]) if research else 0.0
        conf=float(research["confidence"]) if research else 0.0
        edge=fair-ask
        passed=all(f.verdict not in ("FAIL",) for f in findings)
        trade=passed and edge>=0.08 and conf>=0.99
        return {"trade":trade,"fair":fair,"confidence":conf,"edge":edge,
                "findings":[f.__dict__ for f in findings],
                "rank":self.strategist.rank(edge,conf)}
