import json,time
from pathlib import Path

class ResearchInbox:
    def __init__(self,root="data/research_inbox"):
        self.root=Path(root); self.root.mkdir(parents=True,exist_ok=True)

    def load(self,market_id):
        p=self.root/(str(market_id)+".json")
        if not p.exists(): return None
        try:
            x=json.loads(p.read_text())
            fair=float(x["fair_probability"]); conf=float(x["confidence"])
            evidence=x.get("evidence",[])
            domains={str(e.get("domain","")) for e in evidence if isinstance(e,dict)}
            exp=float(x.get("expires_at",time.time()+300))
            if not (0<=fair<=1 and conf>=.99 and len(evidence)>=2 and len(domains)>=2): return None
            if not x.get("resolution_verified") or x.get("conflict") or exp<time.time(): return None
            return {"fair":fair,"confidence":conf}
        except: return None
