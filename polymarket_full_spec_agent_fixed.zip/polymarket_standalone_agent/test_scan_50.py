import os, tempfile, json, time
from pathlib import Path
os.environ['MODE']='PAPER'
os.environ['DB_PATH']=str(Path(tempfile.gettempdir())/'poly_scan50.db')
try: Path(os.environ['DB_PATH']).unlink()
except FileNotFoundError: pass
from agent.core import Agent

a=Agent()
# Replace network API with deterministic fake API so this tests the whole scan path safely.
class FakeAPI:
    def markets(self,limit=500): return [{'id':'m1','question':'Will X happen?','resolutionSource':'https://example.com','endDate':'2099-01-01T00:00:00Z','liquidity':10000,'clobTokenIds':['yes']}]
    def liquidity(self,m): return 10000
    def resolution_source(self,m): return m['resolutionSource']
    def hours_to_resolution(self,m): return 1000
    def token_id(self,m): return 'yes'
    def book(self,t): return {'bids':[{'price':'0.50'}],'asks':[{'price':'0.50'}]}
    def best_prices(self,b): return .5,.5
a.api=FakeAPI()
Path('data/research_inbox').mkdir(parents=True,exist_ok=True)
Path('data/research_inbox/m1.json').write_text(json.dumps({'fair_probability':.7,'confidence':.995,'evidence':[{'claim':'a','domain':'a.com'},{'claim':'b','domain':'b.com','counterclaim':'c'}],'resolution_verified':True,'conflict':False,'expires_at':time.time()+99999}))
a.heartbeat(); a.start()
for i in range(50):
    r=a.scan_once()
    assert r['fetched']==1
    assert r['research']==1
    assert r['signals']==1
    assert r['trades']==1 or len(a.db.open_positions())>=1
print('50/50 FULL SCAN PASSES')
